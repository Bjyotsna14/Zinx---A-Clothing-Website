import React from 'react'

export const LoginSignup = () => {
  return (
    <div>LoginSignup</div>
  )
}
