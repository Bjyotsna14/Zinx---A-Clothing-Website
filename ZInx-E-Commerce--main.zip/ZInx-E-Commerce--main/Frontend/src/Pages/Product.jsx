import React from 'react'

export const Product = () => {
  return (
    <div>Product</div>
  )
}
